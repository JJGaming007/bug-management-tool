// src/components/bugs/CreateBugModal.tsx
'use client'

import React, { useState, DragEvent, useEffect, useRef, KeyboardEvent } from 'react'
import { v4 as uuidv4 } from 'uuid'
import { useAuth } from '@/lib/context/AuthContext'
import { supabase } from '@/lib/supabase'
import { useQueryClient } from '@tanstack/react-query'

type FileWithPreview = { id: string; file: File; preview?: string; uploading?: boolean; progress?: number }

export default function CreateBugModal({ onClose, onCreated }: { onClose: () => void; onCreated?: (r:any) => void }) {
  const auth = (() => { try { return useAuth() } catch { return { user: null } } })()
  const user = auth?.user ?? null
  const qc = (() => { try { return useQueryClient() } catch { return null } })()

  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [priority, setPriority] = useState<'Low'|'Medium'|'High'>('Medium')
  const [dueDate, setDueDate] = useState('')
  const [labels, setLabels] = useState<string[]>([])
  const [newLabel, setNewLabel] = useState('')
  const [files, setFiles] = useState<FileWithPreview[]>([])
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string|null>(null)
  const [debugNote, setDebugNote] = useState<string|null>(null)

  const backdropRef = useRef<HTMLDivElement|null>(null)

  const STORAGE_BUCKET = 'bug-attachments'
  const BUG_TABLE = 'bugs'
  const ATTACH_TABLE = 'bug_attachments'

  useEffect(() => {
    // close on Escape
    function onKey(e: KeyboardEvent | KeyboardEventInit) {
      if ((e as KeyboardEvent).key === 'Escape') {
        onCloseIfAllowed()
      }
    }
    window.addEventListener('keydown', onKey as any)
    return () => window.removeEventListener('keydown', onKey as any)
  }, [])

  function onCloseIfAllowed() {
    if (busy) return // don't allow close while busy creating
    // reset local transient state optionally
    setTitle(''); setDescription(''); setFiles([]); setLabels([]); setNewLabel('')
    setError(null); setDebugNote(null)
    onClose()
  }

  function addFiles(incoming: FileList | File[]) {
    const arr = Array.from(incoming).map(f => ({ id: uuidv4(), file: f, preview: f.type.startsWith('image/') ? URL.createObjectURL(f) : undefined, uploading: false, progress: 0 }))
    setFiles(prev => [...prev, ...arr])
  }
  const handleDrop = (e: DragEvent<HTMLDivElement>) => { e.preventDefault(); if (e.dataTransfer?.files) addFiles(e.dataTransfer.files) }
  const handleDragOver = (e: DragEvent<HTMLDivElement>) => e.preventDefault()
  const removeFile = (id:string) => setFiles(prev => prev.filter(f=>f.id !== id))
  const addLabel = () => { const t=newLabel.trim(); if (t && !labels.includes(t)) { setLabels(p=>[...p,t]); setNewLabel('') } }

  async function uploadFileToStorage(bugId: string|number, fw: FileWithPreview) {
    const key = `${bugId}/${Date.now()}_${fw.file.name.replace(/\s+/g,'_')}`
    setFiles(prev => prev.map(p => p.id===fw.id ? {...p, uploading:true, progress:8} : p))
    const { data, error } = await supabase.storage.from(STORAGE_BUCKET).upload(key, fw.file, { cacheControl: '3600', upsert: false })
    setFiles(prev => prev.map(p => p.id===fw.id ? {...p, uploading:false, progress:100} : p))
    if (error) throw error
    return data.path
  }

  function sanitizePayload(obj: Record<string, any>) {
    const copy = { ...obj }
    if (typeof copy.status === 'string') {
      const s = copy.status.trim().toLowerCase()
      if (s === 'new') copy.status = 'Open'
      else if (s === 'open') copy.status = 'Open'
      else if (s === 'todo' || s === 'to do') copy.status = 'Todo'
      else if (s === 'in progress' || s === 'in_progress' || s === 'inprogress') copy.status = 'In Progress'
      else if (s === 'dev complete' || s === 'dev_complete') copy.status = 'Dev Complete'
      else if (s === 'qa verified' || s === 'qa_verified') copy.status = 'QA Verified'
      else if (s === 'closed' || s === 'resolved') copy.status = 'Closed'
      else if (s === 'reopened' || s === 're-opened') copy.status = 'Reopened'
    }
    return copy
  }

  // prevent Enter in the title field from submitting the form (helps accidental creates)
  function onTitleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Enter') {
      e.preventDefault()
      // move focus to description (optional)
      const ta = document.querySelector<HTMLTextAreaElement>('textarea')
      ta?.focus()
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setDebugNote(null)

    if (title.trim().length < 3) { setError('Title must be at least 3 characters'); return }
    if (description.trim().length < 10) { setError('Description must be at least 10 characters'); return }

    if (!user?.id) { setError('You must be signed in to create a bug.'); return }

    setBusy(true)

    let payload: any = {
      bug_key: uuidv4(),
      title: title.trim(),
      description: description.trim(),
      status: 'Open',
      priority: priority.toLowerCase(),
      due_date: dueDate || null,
      labels: labels.length ? labels : null,
      reporter_id: user.id,
      created_by: user?.id ?? null,
      project_id: null,
    }

    payload = sanitizePayload(payload)

    // LOG payload for debugging
    console.log('[CreateBug] final payload (before insert):', payload)

    let createdBug: any = null
    try {
      const res = await supabase.from(BUG_TABLE).insert(payload).select().single()
      console.log('[CreateBug] insert response:', res)
      if (res.error) throw res.error
      createdBug = res.data
    } catch (err:any) {
      console.error('[CreateBug] insert error:', err)
      setBusy(false)
      setError(String(err?.message ?? err))
      setDebugNote('See console logs: final payload & insert response.')
      return
    }

    const attachments: any[] = []
    for (const fw of files) {
      try {
        const identifier = String(createdBug.id ?? createdBug.uuid ?? Date.now())
        const path = await uploadFileToStorage(identifier, fw)
        const { data: attData, error: attErr } = await supabase.from(ATTACH_TABLE).insert({
          bug_id: createdBug.id ?? createdBug.uuid ?? null,
          filename: fw.file.name,
          file_path: path,
          file_size: fw.file.size,
          mime_type: fw.file.type,
          uploaded_by: user?.id ?? null,
        }).select().single()
        if (attErr) throw attErr
        attachments.push(attData)
      } catch (upErr:any) {
        console.error('[CreateBug] attachment error:', upErr)
        setError(prev => prev ? `${prev}; attachment failed: ${fw.file.name}` : `Attachment failed: ${fw.file.name}`)
      }
    }

    try { qc?.invalidateQueries?.(['bugs']) } catch {}

    setBusy(false)
    onCreated?.({ bug: createdBug, attachments })
    onCloseIfAllowed()
  }

  // backdrop click closes modal
  function onBackdropClick(e: React.MouseEvent<HTMLDivElement>) {
    if (e.target === backdropRef.current) {
      onCloseIfAllowed()
    }
  }

  return (
    <div ref={backdropRef} className="modal-backdrop" role="dialog" aria-modal="true" onClick={onBackdropClick} style={{ zIndex:1000 }}>
      <div className="modal card" style={{ width:'720px', maxWidth:'96vw', margin:'auto' }} onClick={e => e.stopPropagation()}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
          <h2>Create Bug</h2>
          <button className="btn" onClick={() => onCloseIfAllowed()} disabled={busy}>Close</button>
        </div>

        {error && <div style={{ background:'rgba(255,30,30,0.06)', color:'#ffb4b4', padding:12, borderRadius:8, marginBottom:12 }}>
          <strong>Error:</strong> {error}
          <div style={{ fontSize:12, marginTop:8 }}>{debugNote}</div>
        </div>}

        <form onSubmit={handleSubmit} style={{ display:'flex', flexDirection:'column', gap:12 }}>
          <label>
            <div>Title</div>
            <input value={title} onChange={e=>setTitle(e.target.value)} onKeyDown={onTitleKeyDown} />
          </label>

          <label>
            <div>Description</div>
            <textarea rows={5} value={description} onChange={e=>setDescription(e.target.value)} />
          </label>

          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
            <div>
              <div>Labels</div>
              <div style={{ display:'flex', gap:8 }}>
                <input value={newLabel} onChange={e=>setNewLabel(e.target.value)} placeholder="New label" />
                <button type="button" onClick={addLabel}>Add</button>
              </div>
            </div>

            <div>
              <div>Priority</div>
              <select value={priority} onChange={e=>setPriority(e.target.value as any)}>
                <option>Low</option><option>Medium</option><option>High</option>
              </select>

              <div>Due Date</div>
              <input type="date" value={dueDate} onChange={e=>setDueDate(e.target.value)} />
            </div>
          </div>

          <div onDragOver={handleDragOver} onDrop={handleDrop} style={{ border:'1px dashed rgba(255,255,255,0.04)', borderRadius:8, padding:12 }}>
            <div style={{ textAlign:'center' }}>
              Drag & drop files here or{' '}
              <label style={{ cursor:'pointer' }}>
                <input type="file" multiple style={{ display:'none' }} onChange={e => { if (e.target.files) addFiles(e.target.files) }} />
                select files
              </label>
            </div>
            {files.length>0 && files.map(f => (
              <div key={f.id} style={{ display:'flex', alignItems:'center', gap:8, marginTop:8 }}>
                {f.preview ? <img src={f.preview} style={{ width:48, height:48, objectFit:'cover' }} /> : <div style={{ width:48, height:48, background:'#0b1116' }} />}
                <div style={{ flex:1 }}>
                  <div>{f.file.name}</div>
                  <div style={{ fontSize:12 }}>{Math.round(f.file.size/1024)} KB</div>
                </div>
                <button type="button" onClick={()=>removeFile(f.id)}>Remove</button>
              </div>
            ))}
          </div>

          <div style={{ display:'flex', justifyContent:'flex-end', gap:12 }}>
            <button type="button" onClick={() => onCloseIfAllowed()} disabled={busy}>Cancel</button>
            <button type="submit" disabled={busy}>{busy ? 'Creating...' : 'Create'}</button>
          </div>
        </form>
      </div>
    </div>
  )
}
