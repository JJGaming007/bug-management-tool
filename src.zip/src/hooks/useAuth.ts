// src/hooks/useAuth.ts

// Re-export the authentication hook
export { useAuth, AuthProvider } from '@/lib/context/AuthContext'
