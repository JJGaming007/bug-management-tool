// src/app/bugs/page.tsx
'use client'

import React, { useState } from 'react'
import dynamic from 'next/dynamic'

// dynamic import the modal to avoid server rendering mismatch
const CreateBugModal = dynamic(() => import('@/components/bugs/CreateBugModal').then(m => m?.default ?? m), { ssr: false })

// BugList is assumed to be a client component (if it is server, remove 'use client' above)
// If BugList is default export:
import BugList from '@/components/bugs/BugList'

export default function BugsPage() {
  const [showNewBug, setShowNewBug] = useState(false)

  // debug logs to help find undefined imports
  // (leave these during the first test only)
  // eslint-disable-next-line no-console
  console.log('CreateBugModal', CreateBugModal)
  // eslint-disable-next-line no-console
  console.log('BugList', BugList)

  return (
    <div style={{ padding: 20 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1>Bugs</h1>
        <button onClick={() => setShowNewBug(true)}>+ New Bug</button>
      </div>

      <div style={{ marginTop: 20 }}>
        <BugList />
      </div>

      {showNewBug && (
        <CreateBugModal
          onClose={() => setShowNewBug(false)}
          onCreated={(r) => {
            setShowNewBug(false)
            console.log('created', r)
            // optionally trigger reload or query invalidation here
          }}
        />
      )}
    </div>
  )
}
